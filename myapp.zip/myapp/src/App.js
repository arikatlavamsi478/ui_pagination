import React from 'react';
import data from './data/mock-data.json';

export default function App() {
  return (
    <>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>AUTHOR</th>
            <th>WIDTH</th>
            <th>HEIGHT</th>
            <th>URL</th>
            <th>DOWNLOADURL</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => {
            return (
              <tr>
                <td>{item.id}</td>
                <td>{item.author}</td>
                <td>{item.width}</td>
                <td>{item.height}</td>
                <td>{item.url}</td>
                <td>{item.download_url}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
}